const form = document.querySelector('#miFormulario');
const texto = document.querySelector('#miTexto');
const resultado = document.querySelector('#resultado');
const botonTareaRapida = document.querySelector('#tarea-rapida');
let tareas = [];

form.addEventListener('submit', function(evento) 
{
  evento.preventDefault();
  const textoIngresado = texto.value;
  const nuevaTarea = document.createElement('div');
  nuevaTarea.classList.add('tarea');
  
  const checkbox = document.createElement('input');
  checkbox.type = 'checkbox';
  checkbox.classList.add('form-check-input');
  nuevaTarea.appendChild(checkbox);
  
  const textoTarea = document.createElement('span');
  textoTarea.textContent = textoIngresado;
  nuevaTarea.appendChild(textoTarea);
  
  const duracioTarea = document.createElement('span');
  duracioTarea.classList.add('tiempo');
  nuevaTarea.appendChild(duracioTarea);
  
  const eliminarTarea = document.createElement('button');
  eliminarTarea.textContent = 'Eliminar';
  eliminarTarea.classList.add('eliminar');
  nuevaTarea.appendChild(eliminarTarea);
  resultado.appendChild(nuevaTarea);
  texto.value = '';

  const fechaCreacion = new Date();

  checkbox.addEventListener('click', function() 
  {
    textoTarea.classList.toggle('tachado');
    const fechaFinalizacion = new Date();
    duracioTarea.textContent = ` Creada: ${fechaCreacion.toLocaleString()} - Realizada: ${fechaFinalizacion.toLocaleString()}`;
    const tiempoTranscurrido = fechaFinalizacion.getTime() - fechaCreacion.getTime();
    tareas.push({
      texto: textoIngresado,
      tiempo: tiempoTranscurrido
    });
  });

  eliminarTarea.addEventListener('click', function() {
    nuevaTarea.remove();
  });
});

botonTareaRapida.addEventListener('click', function() 
{
  if (tareas.length > 0) {
    const tareaMasRapida = tareas.sort(function(a, b) {
      return a.tiempo - b.tiempo;
    })[0];
    alert(`La tarea más rápida en realizarse fue "${tareaMasRapida.texto}" que tardó ${tareaMasRapida.tiempo / 1000} segundos.`);
  } else {
    alert('No se han completado tareas todavía.');
  }
});
